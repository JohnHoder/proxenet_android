#include <android/log.h>

#include <sys/types.h>
#include <sys/stat.h>

#include <fcntl.h>
#include <jni.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>

#define APPNAME "PROXENET"

#define ALOGV(x) __android_log_print(ANDROID_LOG_VERBOSE, APPNAME, x);

jint JNI_OnLoad(JavaVM* vm, void* reserved)
{
    JNIEnv *env;
    //gJavaVM = vm;
    ALOGV("JNI_OnLoad called");
    if (vm->GetEnv((void**) &env, JNI_VERSION_1_4) != JNI_OK) {
        ALOGV("Failed to get the environment using GetEnv()");
        return -1;
    }

    //proxenet_yolo(1, (void*)0, (void*)0);
    
    return JNI_VERSION_1_4;
}

extern "C" {
JNIEXPORT jstring JNICALL
Java_janhodermarsky_proxenet_NativeWrapper_stringFromJNI(JNIEnv *env, jobject thiz)
{
    ALOGV("Hello from Proxenet CPP layer!");
    return env->NewStringUTF("Hello from Proxenet CPP layer!");
}
}



