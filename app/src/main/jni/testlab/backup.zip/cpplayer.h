#include <android/log.h>

#include <sys/types.h>
#include <sys/stat.h>

#include <fcntl.h>
#include <jni.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>

#ifndef CPPLAYER
#define CPPLAYER

extern jint JNI_OnLoad(JavaVM* vm, void* reserved);
extern JNIEXPORT jstring JNICALL Java_janhodermarsky_proxenet_NativeWrapper_stringFromJNI(JNIEnv *env, jobject thiz);

#endif /* CPPLAYER */